# package-manager
Available modules:
* `add-package` -> extract tarball
* `install` -> execute `install.sh` and `extras-install.sh` in package directory
* `uninstall` -> execute `extras-uninstall.sh and `uninstall.sh` in package directory
* `check-status` -> check `status.sh` for all packages
* `check-extras-status` -> check `extras-status.sh` for all packages
* `check-updates`
* `remove-package` -> safely remove package
