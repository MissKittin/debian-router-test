<?php
	$name='Auto suspend';
	$category='Power management';
?>