<?php
	$name='Auto wake-up';
	$category='Power management';
?>