# correct wol
Automatically setup WOL feature at startup.  
**Requires `ethtool` debian package.**

### Settings
Edit `etc/correct-wol.rc`

### Extras
* acpid-mods: acpid-suspend post_suspend script
