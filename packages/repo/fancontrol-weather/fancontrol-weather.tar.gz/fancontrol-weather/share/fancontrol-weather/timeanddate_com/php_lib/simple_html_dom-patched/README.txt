This version of PHP Simple HTML DOM Parser has been
patched to bypass ssl validation.
For more info see simple_html_dom.php comments in the header.

Home page: https://simplehtmldom.sourceforge.io/
Download: https://sourceforge.net/projects/simplehtmldom/
Github mirror: https://github.com/simplehtmldom/simplehtmldom
