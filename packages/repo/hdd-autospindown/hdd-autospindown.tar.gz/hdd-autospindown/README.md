# HDD autospindown
Script to help manage hdparm settings.  
**This script requires hdparm.**

### Configuration
1) enable or disable script in `etc/hdd-autospindown.rc`
2) go to `etc/hdd-autospindown.d` directory
3) copy `TEMPLATE` to eg. `disk-name.rc`
4) edit `disk-name.rc`
