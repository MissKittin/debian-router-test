# notify-daemon-fstrim
fstrim task for notify-daemon  
run trim command every week (or edit `trim_every` in `etc/notify-daemon/events.rc.d/fstrim.rc`)  
**/sbin/fstrim utility required**

### Extras
Config for acpid-mods that checks if /sbin/fstrim is running
