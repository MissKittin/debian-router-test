# rcdown.local
`/etc/rc.local` for shutdown runlevels.

### Configuration
`/usr/local/etc/rcdown.local.d`

### More info
See `/usr/local/etc/rcdown.local.d/README.TXT`
