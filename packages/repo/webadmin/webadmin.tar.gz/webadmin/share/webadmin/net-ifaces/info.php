<h1>Wired inputs</h1>
<table>
	<tr>
		<td style="font-weight: bold;">eth0</td><td>&#9472;&gt;</td><td>Ethernet gateway</td>
	</tr>
	<tr>
		<td style="font-weight: bold;">eth1</td><td>&#9472;&gt;</td><td>1Gbps LAN</td>
	</tr>
	<tr>
		<td style="font-weight: bold;">eth2</td><td>&#9472;&gt;</td><td>100Mbps LAN</td>
	</tr>
</table>