<?php
	$name='Wicd';
	$category='Network';
?>