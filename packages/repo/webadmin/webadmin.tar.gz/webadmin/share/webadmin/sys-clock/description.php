<?php
	$name='Clock';
	$category='System';
?>