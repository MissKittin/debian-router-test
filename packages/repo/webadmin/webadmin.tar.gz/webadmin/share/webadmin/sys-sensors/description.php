<?php
	$name='Sensors';
	$category='System';
?>