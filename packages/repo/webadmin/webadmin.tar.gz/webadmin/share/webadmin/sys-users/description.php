<?php
	$name='Logged users';
	$category='System';
?>